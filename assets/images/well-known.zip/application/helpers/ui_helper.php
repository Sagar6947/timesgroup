<?php
function product($row,$r)
{
    $data = getSingleRowById('tbl_products_image', array('product_id' => $row['product_id']));
    $pattern = getSingleRowById('tbl_pattern', array('id' => $row['pattern']));
    $length = getSingleRowById('tbl_length', array('id' => $row['length']));
    $fabric = getSingleRowById('tbl_fabric', array('id' => $row['fabric']));

    echo '<div class="shop-item product type-product col-md-'.$r.' col-xs-6 col-sm-6 " style="margin-bottom:10px;">
    <div class="side-item">
        <figure class="item-media">
            <a href="' . base_url('product_details/' . $row['product_id'] . '/' . url_title($row['pro_name'], 'dash', true)) . '">
                <img src="' . base_url('uploads/products/') . '' . $data['pi_name'] . '" alt="" style="height:250px;object-fit:cover;">
            </a>
        </figure>
        <div class="shop-item__content recycling">
            <ul class="shop-item__meta-list">
                <li>
                    <a class="shop-item__meta-tag" href="#"> ' .(($row['category_id'] != '39')? $pattern['pattern']:'Jewels') . '</a>
                </li>
                <!-- <li>
                    <div class="star-rating" title="Rated 4.00 out of 5">
                        <span style="width:80%">
                            <strong class="rating">4.00</strong> out of 5
                        </span>
                    </div>
                </li> -->
            </ul>
            <h3 class="shop-item__title">
                <a href="' . base_url('product_details/' . $row['product_id'] . '/' . url_title($row['pro_name'], 'dash', true)) . '">' . $row['pro_name'] . '</a><br>
                <span class="amount" style="font-size:18px;">&#8377; ' . $row['price'] . ' <span style="color:grey;font-size:14px;"><strike>&#8377; ' . $row['old_price'] . '</strike> </span> </span>
            </h3>
            <!-- <p class="shop-item__desc">
                Aliquam sollicitudin neque in ante pretium tincidunt. Etiam volutpat ex a dolor gravida
                convallis...
            </p> -->
            <div class="shop-item__block">
                <!-- <a href="#" class="shop-item__button  addtocart" style="background-color:black;color:white" data-id="' . $row['product_id'] . '">Add to cart</a>  -->
            </div>
        </div>
    </div>
</div>';
}
